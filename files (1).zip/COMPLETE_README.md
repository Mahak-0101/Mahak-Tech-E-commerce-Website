# 🚀 MAHAKTECH FLAGSHIP WEBSITE - COMPLETE PROJECT

**Status:** Production-Ready | Phase 2 Complete ✅  
**Date:** June 28, 2026  
**For:** Mahak Saxena (mahaksaxena2007@gmail.com)

---

## 📦 WHAT'S INCLUDED

This folder contains the **complete, fully-functional MahakTech website** with:

✅ **3D Floating Orb** (Three.js WebGL)  
✅ **Scroll-Linked Animations** (GSAP)  
✅ **Responsive Design** (Tailwind CSS)  
✅ **8 Page Sections** (Hero, Services, Portfolio, etc.)  
✅ **Production-Ready Build** (Next.js 14)  
✅ **TypeScript** (Full type safety)  
✅ **All Source Code** (Ready to customize)  

---

## ⚡ QUICK START (5 MINUTES)

### **1. Open Terminal/Command Prompt**

**Windows:** Right-click folder → "Open PowerShell here"  
**Mac:** Terminal → `cd ~/Downloads/mahaktech-website`  
**Linux:** Open Terminal → navigate to folder  

### **2. Install Dependencies**

```bash
npm install
```

Takes 2-5 minutes. Downloads all libraries (React, Three.js, GSAP, etc.)

### **3. Start Development Server**

```bash
npm run dev
```

### **4. Open Browser**

```
http://localhost:3000
```

**Done!** 🎉 You should see the cinematic 3D experience.

---

## 📁 FOLDER STRUCTURE

```
mahaktech-website/
│
├── src/
│   ├── app/                    # Next.js pages & routes
│   │   ├── page.tsx           # Homepage (main file)
│   │   ├── layout.tsx         # Root layout
│   │   ├── services/page.tsx  # Services page
│   │   ├── work/page.tsx      # Portfolio page
│   │   └── ... (more routes)
│   │
│   ├── components/            # React components
│   │   ├── 3d/               # Three.js 3D orb
│   │   │   └── OrbScene.tsx  # 3D scene (EDIT THIS for 3D changes)
│   │   │
│   │   ├── sections/         # Homepage sections
│   │   │   ├── Hero.tsx      # Hero section (EDIT for hero text)
│   │   │   ├── Services.tsx  # Services grid (EDIT for services)
│   │   │   ├── Statistics.tsx # Stats section (EDIT for numbers)
│   │   │   ├── Portfolio.tsx
│   │   │   ├── Timeline.tsx
│   │   │   └── ... (more sections)
│   │   │
│   │   ├── layout/
│   │   │   ├── Navigation.tsx # Top nav (EDIT for nav links)
│   │   │   └── Footer.tsx     # Footer (EDIT for footer content)
│   │   │
│   │   └── animations/        # Scroll animation system
│   │       └── ScrollManagerInit.tsx
│   │
│   ├── lib/
│   │   ├── constants/
│   │   │   └── tokens.ts      # DESIGN TOKENS (EDIT for colors/spacing)
│   │   │
│   │   └── hooks/             # Animation hooks
│   │       ├── useGPUCapability.ts
│   │       ├── useScrollManager.ts
│   │       └── useScrollTrigger.ts
│   │
│   └── styles/
│       └── globals.css        # Global CSS
│
├── public/                    # Static assets (fonts, images, models)
│
├── package.json              # Dependencies list
├── next.config.js            # Next.js configuration
├── tailwind.config.js        # Tailwind configuration
├── tsconfig.json             # TypeScript configuration
│
├── README.md                 # Project overview
├── SETUP_GUIDE.md           # Detailed setup instructions
├── PHASE_1_COMPLETE.md      # Phase 1 documentation
└── PHASE_2_COMPLETE.md      # Phase 2 documentation (3D + animations)
```

---

## 🎯 WHERE TO MAKE CHANGES

### **Change Hero Text (Main Headline)**
📁 File: `src/components/sections/Hero.tsx`

```typescript
// Line ~70
<h1 className="display text-white">
  Technology <br /> Reimagined    {/* ← EDIT THIS */}
</h1>
```

### **Change Brand Colors**
📁 File: `src/lib/constants/tokens.ts`

```typescript
// Line ~19
electricIndigo: '#5B5FEF',    {/* ← EDIT THIS (hex code) */}
signalCyan: '#00D4C8',
obsidianInk: '#0A0E14',
```

### **Change Services/Products**
📁 File: `src/components/sections/Services.tsx`

```typescript
// Line ~11
const SERVICES = [
  {
    id: 'ai-ml',
    name: 'AI & Machine Learning',  {/* ← EDIT NAME */}
    description: 'Custom AI...',    {/* ← EDIT DESCRIPTION */}
    tags: ['Tag1', 'Tag2'],         {/* ← EDIT TAGS */}
  },
  // ... more items
];
```

### **Change Statistics Numbers**
📁 File: `src/components/sections/Statistics.tsx`

```typescript
// Line ~15
const STATISTICS = [
  {
    id: 'stat-1',
    value: 150,                {/* ← CHANGE NUMBER */}
    label: 'Projects',         {/* ← CHANGE LABEL */}
  },
  // ... more stats
];
```

### **Change Navigation Links**
📁 File: `src/components/layout/Navigation.tsx`

```typescript
// Line ~11
const NAV_ITEMS = [
  { label: 'Work', href: '/work' },        {/* ← EDIT */}
  { label: 'Services', href: '/services' }, {/* ← EDIT */}
  // ... more items
];
```

### **Change Footer**
📁 File: `src/components/layout/Footer.tsx`

```typescript
// Line ~20
const FOOTER_SECTIONS = [
  {
    title: 'Product',
    links: [
      { label: 'Services', href: '/services' },  {/* ← EDIT */}
      // ... more links
    ],
  },
];
```

### **Change 3D Orb Appearance**
📁 File: `src/components/3d/OrbScene.tsx`

```typescript
// Line ~125
const sphereMaterial = new THREE.MeshStandardMaterial({
  metalness: 0.1,           {/* ← Increase for shinier */}
  roughness: 0.05,          {/* ← Decrease for reflective */}
  opacity: 0.85,            {/* ← Change transparency */}
  emissive: COLORS.secondary.signalCyan,  {/* ← Change glow color */}
  emissiveIntensity: 0.1,   {/* ← Change glow brightness */}
});
```

### **Change Animation Speed**
📁 File: `src/lib/constants/tokens.ts`

```typescript
// Line ~103
duration: {
  hero: 900,     {/* ← Change orb load animation (ms) */}
  reveal: 500,   {/* ← Change content reveal speed (ms) */}
  section: 1200, {/* ← Change section transition speed (ms) */}
}
```

---

## 🎮 AVAILABLE COMMANDS

```bash
# Start development (auto-reload on changes)
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Check for TypeScript errors
npm run type-check

# Run linter
npm run lint
```

---

## 📝 HOW TO EDIT & TEST

### **Step 1: Open Code Editor (VS Code Recommended)**

Download VS Code: https://code.visualstudio.com/

Open the `mahaktech-website` folder

### **Step 2: Start Dev Server**

```bash
npm run dev
```

Keep this running in terminal

### **Step 3: Edit a File**

Example - Change hero text:
1. Open: `src/components/sections/Hero.tsx`
2. Find line ~70
3. Change: `Technology <br /> Reimagined` to your text
4. Save: `Ctrl + S` (or `Cmd + S` on Mac)

### **Step 4: See Changes Instantly**

Browser auto-refreshes! No restart needed. ✨

---

## 🚀 DEPLOY TO LIVE SERVER

### **Option 1: Vercel (Free, Recommended)**

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel
```

Follow prompts. Your site is live in 2 minutes!

### **Option 2: GitHub + Vercel**

1. Create GitHub account: https://github.com/signup
2. Create new repository
3. Push code: 
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

4. Go to https://vercel.com
5. Import from GitHub
6. Click Deploy

### **Option 3: Docker (Advanced)**

```bash
docker build -t mahaktech .
docker run -p 3000:3000 mahaktech
```

---

## 🔧 COMMON TASKS

### **Add a New Section to Homepage**

1. Create new file: `src/components/sections/MySection.tsx`
2. Write component:
```typescript
export default function MySection() {
  return (
    <section id="my-section" className="w-full bg-white py-32 px-4">
      {/* Your content */}
    </section>
  );
}
```

3. Import in `src/app/page.tsx`:
```typescript
import MySection from '@/components/sections/MySection';
```

4. Add to homepage:
```typescript
<MySection />
```

### **Change All Brand Colors at Once**

Edit `src/lib/constants/tokens.ts` COLORS section. All components automatically update.

### **Add Custom Font**

1. Download font from: https://fonts.google.com/
2. Add to `public/fonts/`
3. Edit `src/app/layout.tsx` font preload links
4. Update `src/lib/constants/tokens.ts` font family

### **Disable 3D Orb (Use Static Image Instead)**

Edit `src/components/sections/Hero.tsx`:
```typescript
// Comment out the OrbScene
// <OrbScene scrollProgress={scrollProgress} />

// Add static image instead
<img src="/hero-image.jpg" alt="Hero" className="absolute inset-0" />
```

---

## 🐛 TROUBLESHOOTING

### **"npm: command not found"**
→ Install Node.js: https://nodejs.org/

### **"Port 3000 is already in use"**
→ Run: `npm run dev -- -p 3001`

### **No 3D orb visible**
→ Try Chrome/Firefox/Edge (latest versions)
→ Check console for WebGL errors
→ Update graphics drivers

### **Changes not showing**
→ Save file (Ctrl + S)
→ Refresh browser (Ctrl + R or F5)
→ Check browser console for errors

### **npm install is very slow**
→ Normal for first install
→ Don't cancel
→ Wait 5-10 minutes

---

## 📖 DOCUMENTATION FILES

Inside project folder:

- **README.md** - Project overview
- **PHASE_1_COMPLETE.md** - Design system documentation
- **PHASE_2_COMPLETE.md** - 3D orb & scroll animation details
- **SETUP_GUIDE.md** - Detailed setup instructions

---

## ✅ CUSTOMIZATION CHECKLIST

- [ ] Change hero headline text
- [ ] Update brand colors
- [ ] Edit services/products list
- [ ] Update statistics numbers
- [ ] Change navigation links
- [ ] Update footer content
- [ ] Customize 3D orb appearance
- [ ] Adjust animation speeds
- [ ] Add your own images/assets
- [ ] Deploy to live server

---

## 🎯 YOU'RE READY!

**Everything you need is in this folder:**
- ✅ Complete source code
- ✅ All dependencies configured
- ✅ Production-ready build
- ✅ Documentation included
- ✅ Easy to customize

**Just run:**
```bash
npm install
npm run dev
```

**And start editing!** 🚀

---

## 💬 QUICK REFERENCE

| Need | File | What to Change |
|------|------|---|
| Change hero text | `src/components/sections/Hero.tsx` | Line 70 |
| Change colors | `src/lib/constants/tokens.ts` | Line 19-25 |
| Change services | `src/components/sections/Services.tsx` | Line 11 SERVICES array |
| Change stats | `src/components/sections/Statistics.tsx` | Line 15 STATISTICS array |
| Change nav | `src/components/layout/Navigation.tsx` | Line 11 NAV_ITEMS |
| Change footer | `src/components/layout/Footer.tsx` | Line 20 FOOTER_SECTIONS |
| Change 3D orb | `src/components/3d/OrbScene.tsx` | Line 125 sphereMaterial |
| Change animation speed | `src/lib/constants/tokens.ts` | Line 103 duration |

---

## 🎉 ENJOY!

This is a **production-ready** website. Everything works out of the box.

Customize it, deploy it, and share it with the world! 🌍

---

**Built with:** React • Next.js • Three.js • GSAP • Tailwind CSS  
**Status:** Complete & Ready to Deploy  
**Last Updated:** June 28, 2026

Happy coding! 💻✨
