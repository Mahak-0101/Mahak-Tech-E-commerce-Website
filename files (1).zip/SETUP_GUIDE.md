# 🚀 MAHAKTECH WEBSITE — SETUP GUIDE

## For: Mahak Saxena
## Email: mahaksaxena2007@gmail.com
## Date: June 28, 2026

---

## 📥 STEP 1: DOWNLOAD THE PROJECT

**Download file:** `mahaktech-website-clean.tar.gz` (96 KB)

Save it to: `Downloads` folder or anywhere on your computer

---

## 🗜️ STEP 2: EXTRACT THE FILE

### **Windows Users:**
1. Right-click on `mahaktech-website-clean.tar.gz`
2. Choose "Extract All..."
3. Select destination (e.g., Desktop or Documents)
4. Click Extract

**OR** Install 7-Zip (free): https://www.7-zip.org/

### **Mac/Linux Users:**
Open Terminal and run:
```bash
cd ~/Downloads
tar -xzf mahaktech-website-clean.tar.gz
```

This creates folder: `mahaktech-website/`

---

## ✅ STEP 3: INSTALL NODE.JS (If You Don't Have It)

**Check if installed:**
```bash
node --version
npm --version
```

**If NOT installed:**
- Download: https://nodejs.org/
- Click **LTS** (Long Term Support)
- Install normally
- Restart computer

---

## 🔧 STEP 4: OPEN TERMINAL IN PROJECT FOLDER

### **Windows:**
1. Extract folder to Desktop or Documents
2. Right-click on `mahaktech-website` folder
3. Click "Open PowerShell window here" (or "Open Command Prompt here")
4. Terminal opens in the correct folder

### **Mac:**
1. Open Terminal (Cmd + Space, type "terminal")
2. Drag the `mahaktech-website` folder into the terminal
3. Press Enter
4. Or: `cd ~/Desktop/mahaktech-website` (if on Desktop)

### **Linux:**
1. Open Terminal
2. `cd ~/Desktop/mahaktech-website` (or wherever you extracted)

---

## 📚 STEP 5: INSTALL DEPENDENCIES

In the terminal (in the project folder), run:

```bash
npm install
```

**What happens:**
- Downloads ~500MB of libraries
- Takes 2-5 minutes
- Creates `node_modules` folder
- You'll see: "added X packages"

**After it's done, you see:**
```
added 382 packages in 2m 45s
```

---

## 🚀 STEP 6: START DEVELOPMENT SERVER

In the SAME terminal, run:

```bash
npm run dev
```

**You should see:**
```
  ▲ Next.js 14.2.35
  - Local:        http://localhost:3000

 ✓ Ready in 1.8s
```

**This means it's running!** ✅

---

## 🌐 STEP 7: OPEN IN BROWSER

**Go to:**
```
http://localhost:3000
```

Or simply click: http://localhost:3000

**You should see:**
- ✅ MahakTech navigation bar at top
- ✅ Full-screen dark hero section
- ✅ **3D Floating Orb** (glowing cyan sphere with indigo wireframe)
- ✅ Text: "Technology Reimagined"
- ✅ Scroll indicator at bottom

---

## 🎮 INTERACT WITH IT

**What to try:**
1. **Scroll down** → Watch orb shrink and move right
2. **Move mouse** → Orb glow gets brighter
3. **Scroll to Services** → Cards appear with animations
4. **Scroll to Statistics** → Numbers count up (150+, 99.99%, etc.)
5. **Scroll through entire page** → Full cinematic experience

---

## 🛠️ EDIT THE CODE

### **Want to change colors?**

Edit: `src/lib/constants/tokens.ts`

Find:
```typescript
electricIndigo: '#5B5FEF',
```

Change the hex code, save file → Browser auto-refreshes!

### **Want to change text?**

Edit: `src/components/sections/Hero.tsx`

Find:
```typescript
<h1 className="display text-white">
  Technology <br /> Reimagined
</h1>
```

Edit the text, save → Instantly updates!

### **Want to use a code editor?**

**Install VS Code (free):**
- Download: https://code.visualstudio.com/
- Open the `mahaktech-website` folder in VS Code
- Edit files there
- Terminal is built-in (View → Terminal)

---

## ⏹️ STOP THE SERVER

In the terminal, press:
```
Ctrl + C
```

This stops the development server. You can restart anytime with `npm run dev`.

---

## 🚨 TROUBLESHOOTING

### **Error: "npm: command not found"**
→ Node.js not installed
→ Download: https://nodejs.org/

### **Error: "Port 3000 is already in use"**
→ Another app using port 3000
→ Option 1: Close that app
→ Option 2: Run: `npm run dev -- -p 3001`

### **Page loads but no 3D orb visible**
→ WebGL not supported in your browser
→ Try: Chrome, Firefox, or Edge (latest versions)

### **Animations are slow/jittery**
→ GPU is limited (normal on older devices)
→ System auto-selects "low quality" tier
→ Still fully functional

### **npm install is very slow**
→ Slow internet connection
→ Wait 5-10 minutes
→ Don't cancel the process

---

## 🔄 COMMON COMMANDS

```bash
# Start development server (run code live)
npm run dev

# Build for production (optimize for deployment)
npm run build

# Run production build locally
npm start

# Check for errors
npm run type-check

# Run linter (check code quality)
npm run lint
```

---

## 📱 BUILD & DEPLOY

### **Build for Production:**
```bash
npm run build
```

Creates optimized version in `.next/` folder.

### **Deploy to Vercel (Free):**
1. Push code to GitHub
2. Go to https://vercel.com
3. Click "Import Project"
4. Select your GitHub repo
5. Click Deploy
6. Your site is live in 2 minutes!

---

## 📞 IF YOU GET STUCK

**Most common issues:**

| Problem | Solution |
|---------|----------|
| npm not found | Install Node.js from nodejs.org |
| Port 3000 in use | Run: `npm run dev -- -p 3001` |
| No WebGL/3D orb | Use Chrome/Firefox/Edge |
| Very slow npm install | Just wait, don't cancel |
| Terminal won't open | Right-click folder, "Open PowerShell here" |

---

## ✨ PROJECT STRUCTURE

```
mahaktech-website/
├── src/
│   ├── components/         # React components
│   │   ├── 3d/            # 3D orb (Three.js)
│   │   ├── sections/      # Page sections
│   │   └── layout/        # Nav, Footer
│   ├── lib/
│   │   ├── constants/     # Colors, spacing (tokens)
│   │   └── hooks/         # Animation logic
│   ├── app/               # Pages/routes
│   └── styles/            # CSS
├── public/                # Fonts, images, models
├── package.json           # Dependencies
├── next.config.js         # Configuration
└── README.md              # Documentation
```

---

## 🎯 QUICK START CHECKLIST

- [ ] Download `mahaktech-website-clean.tar.gz`
- [ ] Extract the file
- [ ] Install Node.js (if needed)
- [ ] Open terminal in project folder
- [ ] Run `npm install`
- [ ] Run `npm run dev`
- [ ] Open http://localhost:3000
- [ ] **Enjoy! 🎉**

---

## 📖 NEXT STEPS

### **Want to learn more?**
Read the full documentation:
- `README.md` — Project overview
- `PHASE_1_COMPLETE.md` — Design system & foundation
- `PHASE_2_COMPLETE.md` — 3D orb & scroll animations
- `QUICK_START.md` — Development guide

### **Want to customize it?**
Edit files in `src/` folder while `npm run dev` is running. Browser auto-refreshes!

### **Want to add features?**
Components are modular. Add new sections to `src/components/sections/`.

---

## 🚀 YOU'RE ALL SET!

Everything is ready. Just download, extract, and run.

**Enjoy the cinematic 3D experience!** ✨

---

**Questions?** Feel free to ask!

**Built with:** React, Next.js, Three.js, GSAP, Tailwind CSS  
**Status:** Production-ready, Phase 2 complete  
**Last Updated:** June 28, 2026
